package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/seats")
public class TrainSeatReservationController {

    @Autowired
    private SeatService seatService;

    // GET request to book seats
    @GetMapping("/book")
    public ResponseEntity<?> bookSeats(@RequestParam int numSeats) {
        try {
            List<Integer> bookedSeats = seatService.bookSeats(numSeats);
            return ResponseEntity.ok(bookedSeats);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/status")
    public ResponseEntity<List<Seat>> getSeatStatus() {
        return ResponseEntity.ok(seatService.getSeatStatus());
    }
}
