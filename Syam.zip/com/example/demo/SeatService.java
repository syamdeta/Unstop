package com.example.demo;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatService {

    private static final int TOTAL_SEATS = 80;
    private static final int ROW_SIZE = 7;
    private List<Seat> seats;

    // Constructor to initialize the seats
    public SeatService() {
        seats = new ArrayList<>();
        for (int i = 1; i <= TOTAL_SEATS; i++) {
            seats.add(new Seat(i, false));  // All seats are initially not reserved
        }
    }

    // Method to book seats
    public List<Integer> bookSeats(int noSeat) throws Exception {
        if (noSeat < 1 || noSeat > ROW_SIZE) {
            throw new Exception("Invalid number of seats to book. You can book between 1 and 7 seats.");
        }

        // Get available seats
        List<Seat> available = seats.stream()
                .filter(seat -> !seat.isReserved())
                .collect(Collectors.toList());

        if (available.size() < noSeat) {
            throw new Exception("Not enough available seats.");
        }

        List<Seat> seatsToBook = new ArrayList<>();
        // Try to book in the same row if possible
        for (Seat seat : available) {
            if (seatsToBook.size() == noSeat) break;
            if (isInSameRow(seatsToBook, seat)) {
                seatsToBook.add(seat);
            }
        }

        // If not enough seats in the same row, book any available seats
        if (seatsToBook.size() < noSeat) {
            seatsToBook = available.subList(0, noSeat);
        }

        // Mark these seats as reserved
        for (Seat seat : seatsToBook) {
            seat.setReserved(true);
        }

        return seatsToBook.stream()
                .map(Seat::getSeatNo)
                .collect(Collectors.toList());
    }

    // Method to check if the seats are in the same row
    private boolean isInSameRow(List<Seat> seatsToBook, Seat seat) {
        if (seatsToBook.isEmpty()) return true;
        int lastSeat = seatsToBook.get(seatsToBook.size() - 1).getSeatNo();
        return (lastSeat / ROW_SIZE) == (seat.getSeatNo() / ROW_SIZE);
    }

    // Method to get the seat status
    public List<Seat> getSeatStatus() {
        return seats;
    }
}

