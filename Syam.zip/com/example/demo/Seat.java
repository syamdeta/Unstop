package com.example.demo;

public class Seat {

    private int seatNo;
    private boolean Reserved;

    public Seat(int seatNo, boolean Reserved) {
        this.seatNo = seatNo;
        this.Reserved = Reserved;
    }
 // Getter and Setter methods


	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
// It is used to return the status of the "false" for not reserved and "true" for reserved
	public boolean isReserved() {
		return Reserved;
	}

	public void setReserved(boolean reserved) {
		Reserved = reserved;
	}

    
}
